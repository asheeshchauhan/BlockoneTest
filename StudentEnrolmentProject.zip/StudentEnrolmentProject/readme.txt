RESTFul API Implementation and Testing Steps:-

Implementation:-
1. I create four packages for Student Enrollment
2. In "Student Controller Class" I passed api URL which are inculding all type i.e POST,PUT,DELETE & GET
3. We can start the application via Start Application class
4. I added Testautomationclass package :- in this package I added couple of scenario to test the application, same as it we can design multiple
test scenario and multiple types of validations.
5. This is a sample class, I used cucumber keyboard and testNG annotation
6. Further we can enhance this structure as a proper BDD format i.e Fetaures files, Step Defination fiel & test Runner class 
  